"""Property synthesis package."""
